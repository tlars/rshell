#ifndef PADDLEBOAT_H
#define PADDLEBOAT_H

#include "Seats.h"
using namespace std;

class PaddleBoat:public Seats{
protected:
	int num_of_doors;
	string shape_of_boat;
public:
	PaddleBoat();
	void go(double);

};
PaddleBoat::PaddleBoat(){
	speed_per_hour=10;
	num_of_seats=2;
	num_of_doors=2;
	shape_of_boat="Swan";
	name="PaddleBoat";
}
void PaddleBoat::go(double s){
	cout<<name<<endl;
	cout<<"Distance = "<<s*speed_per_hour<<endl;
}
#endif
