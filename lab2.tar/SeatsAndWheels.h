#ifndef SEATSANDWHEELS_H
#define SEATSANDWHEELS_H
#include "Vehicle.h"
using namespace std;
class SeatsAndWheels:public Vehicle{
protected:
	int num_of_seats;
	int num_of_wheels;
public:
	SeatsAndWheels();
	void go(double);
	
};
SeatsAndWheels::SeatsAndWheels(){
	num_of_seats=0;
	num_of_wheels=0;
	speed_per_hour=0;
	name="Seats and Wheels";
}
void SeatsAndWheels::go(double){
}
#endif
