#ifndef VEHICLE_H
#define VEHICLE_H
#include <iostream>
#include <string>
using namespace std;
class Vehicle{
protected:
	string name;
	double speed_per_hour;
public:
	Vehicle();
	virtual void go(double );
};
Vehicle::Vehicle(){
	speed_per_hour=0;
	name="Vehicle";
}
void Vehicle::go(double s){


}
#endif
