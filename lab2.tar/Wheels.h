#ifndef WHEELS_H
#define WHEELS_H
#include "Vehicle.h"
using namespace std;
class Wheels:public Vehicle{
protected:
	int num_of_wheels;
public:
	Wheels();
	void go(double);
	
};
Wheels::Wheels(){
	num_of_wheels=0;
	speed_per_hour=0;
	name=" Wheels";
}
void Wheels::go(double){
}
#endif
