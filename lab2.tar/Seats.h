#ifndef SEATS_H
#define SEATS_H
#include "Vehicle.h"
using namespace std;
class Seats:public Vehicle{
protected:
	int num_of_seats;
public:
	Seats();
	void go(double);
	
};
Seats::Seats(){
	num_of_seats=0;
	speed_per_hour=0;
	name="Seats";
}
void Seats::go(double){
}
#endif
