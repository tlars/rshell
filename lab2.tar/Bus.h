#ifndef BUS_H
#define BUS_H

#include "SeatsAndWheels.h"
using namespace std;

class Bus:public SeatsAndWheels{
protected:
	double fare;
	int num_of_doors;
public:
	Bus();
	void go(double);

};
Bus::Bus(){
	speed_per_hour=50;
	num_of_seats=40;
	num_of_wheels=6;
	num_of_doors=2;
	fare=1.25;
	name="Bus";
}
void Bus::go(double s){
	cout<<name<<endl;
	cout<<"Distance = "<<s*speed_per_hour<<endl;
}
#endif
