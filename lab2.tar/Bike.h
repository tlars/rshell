#ifndef BIKE_H
#define BIKE_H

#include "SeatsAndWheels.h"
using namespace std;

class Bike:public SeatsAndWheels{
protected:

public:
	Bike();
	void go(double);

};
Bike::Bike(){
	speed_per_hour=25.25;
	num_of_seats=1;
	num_of_wheels=2;
	name="Bicycle";
}
void Bike::go(double s){
	cout<<name<<endl;
	cout<<"Distance = "<<s*speed_per_hour<<endl;
}
#endif
