#ifndef RocketBlades_H
#define RocketBlades_H

#include "Wheels.h"
using namespace std;

class RocketBlades:public Wheels{
public:
	RocketBlades();
	bool saftey;
	void go(double);

};
RocketBlades::RocketBlades(){
	speed_per_hour=60;
	num_of_wheels=6;
	saftey=false;
	name="RocketBlades";
}
void RocketBlades::go(double s){
	cout<<name<<endl;
	cout<<"Distance = "<<s*speed_per_hour<<endl;
}
#endif
