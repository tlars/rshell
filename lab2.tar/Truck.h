#ifndef TRUCK_H
#define TRUCK_H

#include "SeatsAndWheels.h"
using namespace std;

class Truck:public SeatsAndWheels{
protected:
	int payload;
	int num_of_doors;
public:
	Truck();
	void go(double);

};
Truck::Truck(){
	speed_per_hour=75;
	num_of_seats=5;
	num_of_wheels=4;
	num_of_doors=4;
	payload=2000;
	name="Truck";
}
void Truck::go(double s){
	cout<<name<<endl;
	cout<<"Distance = "<<s*speed_per_hour<<endl;
}
#endif
