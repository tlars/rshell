#include "Sedan.h"
#include "Bike.h"
#include "Motor.h"
#include "Truck.h"
#include "Coup.h"
#include "Hover.h"
#include "RocketBlades.h"
#include "FalconRocket.h"
#include "Bus.h"
#include "PaddleBoat.h"
#include "MetroLink.h"
#include <vector>
//Todd Larson
//861106862
//Cs 100 Lab2
using namespace std;

int main(){

	vector<Vehicle*> vehicle;
	vehicle.push_back(new Sedan());
	vehicle.push_back(new Coup());
	vehicle.push_back(new Truck());
	vehicle.push_back(new Bike());
	vehicle.push_back(new Motorcycle());
	vehicle.push_back(new Bus());
	vehicle.push_back(new Hoverboard());
	vehicle.push_back(new RocketBlades());
	vehicle.push_back(new FalconRocket());
	vehicle.push_back(new MetroLink());
	vehicle.push_back(new PaddleBoat());
	
	cout<<"Put in 2 for the time"<<endl;
	for(unsigned i = 0; i < vehicle.size(); i++){
		vehicle[i]->go(2);
		cout<<endl;
	}
	cout<<"Put 3.1415 for the time"<<endl;
		for(unsigned i = 0; i < vehicle.size(); i++){
		vehicle[i]->go(3.1415);
		cout<<endl;
	}
	return 0;

}
