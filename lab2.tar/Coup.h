#ifndef COUP_H
#define COUP_H
#include "SeatsAndWheels.h"
using namespace std;

class Coup:public SeatsAndWheels{
protected:

	int num_of_doors;


public:
	Coup();
	void go(double);

};
Coup::Coup(){
	speed_per_hour=120;
	num_of_seats=4;
	num_of_doors=2;
	num_of_wheels=4;
	name="Coup";
} 
void Coup::go(double s){
	cout<<name<<endl;
	cout<<"Distance = "<<s*speed_per_hour<<endl;
}
#endif
