#ifndef SEDAN_H
#define SEDAN_H

#include "SeatsAndWheels.h"
using namespace std;

class Sedan:public SeatsAndWheels{
protected:

	int num_of_doors;


public:
	Sedan();
	void go(double);

};
Sedan::Sedan(){
	speed_per_hour=100;
	num_of_seats=4;
	num_of_doors=2;
	num_of_wheels=4;
	name="Sedan";
}
void Sedan::go(double s){
	cout<<name<<endl;
	cout<<"Distance = "<<s*speed_per_hour<<endl;
}
#endif
