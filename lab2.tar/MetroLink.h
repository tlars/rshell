#ifndef METROLINK_H
#define METROLINK_H

#include "Seats.h"
using namespace std;

class MetroLink:public Seats{
protected:
	int num_of_doors;
	int num_of_cars;
public:
	MetroLink();
	void go(double);

};
MetroLink::MetroLink(){
	speed_per_hour=45;
	num_of_seats=100;
	num_of_doors=10;
	num_of_cars=5;
	name="MetroLink";
}
void MetroLink::go(double s){
	cout<<name<<endl;
	cout<<"Distance = "<<s*speed_per_hour<<endl;
}
#endif
