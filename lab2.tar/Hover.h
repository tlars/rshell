#ifndef HOVERBOARD_H
#define HOVERBOARD_H

#include "Wheels.h"
using namespace std;

class Hoverboard:public Wheels{
public:
	Hoverboard();
	void go(double);

};
Hoverboard::Hoverboard(){
	speed_per_hour=30;
	num_of_wheels=4;
	name="Hoverboard";
}
void Hoverboard::go(double s){
	cout<<name<<endl;
	cout<<"Distance = "<<s*speed_per_hour<<endl;
}
#endif
