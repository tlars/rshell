#ifndef MOTOR_H
#define MOTOR_H

#include "SeatsAndWheels.h"
using namespace std;

class Motorcycle:public SeatsAndWheels{
public:
	Motorcycle();
	void go(double);

};
Motorcycle::Motorcycle(){
	speed_per_hour=80;
	num_of_seats=1;
	num_of_wheels=2;
	name="Motorcycle";
}
void Motorcycle::go(double s){
	cout<<name<<endl;
	cout<<"Distance = "<<s*speed_per_hour<<endl;
}
#endif
